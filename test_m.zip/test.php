<?php

$a ="1";
$b ="Yes";
$c ='ABCD';
$res = " Byby {$a} with to {$b} ghjhgjdfsdfdf {$c}";
echo $res;